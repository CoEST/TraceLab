﻿using System;
// Located in c:\Program Files (x86)\COEST\TraceLab\lib\TraceLabSDK.dll
using TraceLabSDK;

namespace $rootnamespace$
{
    [Component(	Name = "$componentname$",
                Description = "$description$",
                Author = "$author$",
                Version = "1.0")]
	//[IOSpec(IOType = IOSpecType.Output, Name = "outputName", DataType = typeof(int))]
    public class $safeitemname$ : BaseComponent
    {
        public $safeitemname$(ComponentLogger log) : base(log) { }

        public override void Compute()
        {
            // your component implementation
			Logger.Trace("Hello World");
			
			//Workspace.Store("outputName", 5);
        }
    }
}